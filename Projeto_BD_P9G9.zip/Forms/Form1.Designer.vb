﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ListViewItem1 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("")
        Me.TabControl = New System.Windows.Forms.TabControl()
        Me.GameTab = New System.Windows.Forms.TabPage()
        Me.GameAlterButton = New System.Windows.Forms.Button()
        Me.gameAddSaveMachine = New System.Windows.Forms.Button()
        Me.selectMachineForGame = New System.Windows.Forms.ComboBox()
        Me.removeGamefromMachine = New System.Windows.Forms.Button()
        Me.addGameToMAchineButton = New System.Windows.Forms.Button()
        Me.GameMachineLabel = New System.Windows.Forms.Label()
        Me.GameMachinesListBox = New System.Windows.Forms.ListBox()
        Me.GameCancelButton = New System.Windows.Forms.Button()
        Me.GameEditButton = New System.Windows.Forms.Button()
        Me.GameDeleteButton = New System.Windows.Forms.Button()
        Me.GameAddButton = New System.Windows.Forms.Button()
        Me.GameSaveButton = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.GameCostInput = New System.Windows.Forms.TextBox()
        Me.GameCostLabel = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.GamePlayersInput = New System.Windows.Forms.TextBox()
        Me.GamePlayersLabel = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.GamePointsInput = New System.Windows.Forms.TextBox()
        Me.GamePointsLabel = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.GameIDInput = New System.Windows.Forms.TextBox()
        Me.GameIDLabel = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.GamePublisherInput = New System.Windows.Forms.ComboBox()
        Me.GamePublisherLabel = New System.Windows.Forms.Label()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.GameNameInput = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GameListBox = New System.Windows.Forms.ListBox()
        Me.Publisher = New System.Windows.Forms.TabPage()
        Me.PublisherCancelButton = New System.Windows.Forms.Button()
        Me.PublisherEditButton = New System.Windows.Forms.Button()
        Me.PublisherAddButton = New System.Windows.Forms.Button()
        Me.PublisherSaveButton = New System.Windows.Forms.Button()
        Me.PublisherInfo = New System.Windows.Forms.GroupBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.PublisherLocationInput = New System.Windows.Forms.TextBox()
        Me.PublisherLocationLabel = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.PublisherIsIndependent = New System.Windows.Forms.CheckBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.PublisherIDInput = New System.Windows.Forms.TextBox()
        Me.PublisherIDLabel = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.PublisherNameInput = New System.Windows.Forms.TextBox()
        Me.PublisherNameLabel = New System.Windows.Forms.Label()
        Me.PublisherListBox = New System.Windows.Forms.ListBox()
        Me.SupplierTab = New System.Windows.Forms.TabPage()
        Me.SupplierCancelEditButton = New System.Windows.Forms.Button()
        Me.SupplierEditButton = New System.Windows.Forms.Button()
        Me.SupplierDeleteButton = New System.Windows.Forms.Button()
        Me.SupplierAddButton = New System.Windows.Forms.Button()
        Me.SupplierSaveButton = New System.Windows.Forms.Button()
        Me.SupplierInfo = New System.Windows.Forms.GroupBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.SupplierAddressInput = New System.Windows.Forms.TextBox()
        Me.SupplierAddressLabel = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.SupplierEmailInput = New System.Windows.Forms.TextBox()
        Me.SupplierEmailLabel = New System.Windows.Forms.Label()
        Me.SupplierPhoneDetails = New System.Windows.Forms.Panel()
        Me.SupplierPhoneInput = New System.Windows.Forms.TextBox()
        Me.SupplierPhoneLabel = New System.Windows.Forms.Label()
        Me.SupplierNIFDetails = New System.Windows.Forms.Panel()
        Me.SupplierNIFInput = New System.Windows.Forms.TextBox()
        Me.SupplierNIFLabel = New System.Windows.Forms.Label()
        Me.SupplierNameDetails = New System.Windows.Forms.Panel()
        Me.SupplierNameInput = New System.Windows.Forms.TextBox()
        Me.SupplierNameLabel = New System.Windows.Forms.Label()
        Me.Supplier_ListBox = New System.Windows.Forms.ListBox()
        Me.StoreTab = New System.Windows.Forms.TabPage()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.EmployeeDeleteButton = New System.Windows.Forms.Button()
        Me.EmployeeAddButton = New System.Windows.Forms.Button()
        Me.EmployeeSaveButton = New System.Windows.Forms.Button()
        Me.EmployeeCancelButton = New System.Windows.Forms.Button()
        Me.EmployeeEditButton = New System.Windows.Forms.Button()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.EmpTaskList = New System.Windows.Forms.ListView()
        Me.employeeFuncLabel = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.EmployeeEndVal = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.EmployeeStartVal = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.EmployeeNIFInput = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.EmployeeSalaryInput = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.EmployeePhoneInput = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.EmployeeEmailInput = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.EmployeeNameInput = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.EmployeeListBox = New System.Windows.Forms.ListBox()
        Me.StoreCancelButton = New System.Windows.Forms.Button()
        Me.StoreEditButton = New System.Windows.Forms.Button()
        Me.StoreDeleteButton = New System.Windows.Forms.Button()
        Me.StoreAddButton = New System.Windows.Forms.Button()
        Me.StoreSaveButton = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.StoreIDInput = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.StoreLocationInput = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.StoreListBox = New System.Windows.Forms.ListBox()
        Me.LogTab = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.totalTime = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.avgTime = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.StartTimeStats = New System.Windows.Forms.DateTimePicker()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.EmployeeLogs = New System.Windows.Forms.ComboBox()
        Me.RedeemShowLogs = New System.Windows.Forms.Button()
        Me.topupShowLogs = New System.Windows.Forms.Button()
        Me.ShowMaintenanceLog = New System.Windows.Forms.Button()
        Me.ShowPlayLog = New System.Windows.Forms.Button()
        Me.LogGrid = New System.Windows.Forms.DataGridView()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GameMachineAddButton = New System.Windows.Forms.Button()
        Me.GameMachineSaveButton = New System.Windows.Forms.Button()
        Me.GameMachineCancelButton = New System.Windows.Forms.Button()
        Me.GameMachineEditButton = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.GameMachineRentDurInput = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GameMachineRentInput = New System.Windows.Forms.TextBox()
        Me.GameMachineRentCost = New System.Windows.Forms.Label()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.GameMachineSupplierInput = New System.Windows.Forms.ComboBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.GameMachineLocationInput = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.GameMachineManuInput = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.GameMachineSerialInput = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.MachinaListBox = New System.Windows.Forms.ListBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.RedeemedBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ArcadeData = New Projeto_BD.ArcadeData()
        Me.ToppedUpBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MaintainedBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PlayedBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RedeemedBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RedeemedTableAdapter = New Projeto_BD.ArcadeDataTableAdapters.RedeemedTableAdapter()
        Me.ToppedUpTableAdapter = New Projeto_BD.ArcadeDataTableAdapters.ToppedUpTableAdapter()
        Me.MaintainedTableAdapter = New Projeto_BD.ArcadeDataTableAdapters.MaintainedTableAdapter()
        Me.PlayedTableAdapter = New Projeto_BD.ArcadeDataTableAdapters.PlayedTableAdapter()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.statisticsButtonGo = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.EndTimeStats = New System.Windows.Forms.DateTimePicker()
        Me.userStat = New System.Windows.Forms.ComboBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.gameStat = New System.Windows.Forms.ComboBox()
        Me.statsUseStart = New System.Windows.Forms.CheckBox()
        Me.StatsuseEnd = New System.Windows.Forms.CheckBox()
        Me.TabControl.SuspendLayout()
        Me.GameTab.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Publisher.SuspendLayout()
        Me.PublisherInfo.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.SupplierTab.SuspendLayout()
        Me.SupplierInfo.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SupplierPhoneDetails.SuspendLayout()
        Me.SupplierNIFDetails.SuspendLayout()
        Me.SupplierNameDetails.SuspendLayout()
        Me.StoreTab.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel24.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.LogTab.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.LogGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.Panel29.SuspendLayout()
        Me.Panel30.SuspendLayout()
        Me.Panel31.SuspendLayout()
        Me.Panel32.SuspendLayout()
        CType(Me.RedeemedBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ArcadeData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ToppedUpBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaintainedBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PlayedBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RedeemedBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl
        '
        Me.TabControl.Controls.Add(Me.GameTab)
        Me.TabControl.Controls.Add(Me.Publisher)
        Me.TabControl.Controls.Add(Me.SupplierTab)
        Me.TabControl.Controls.Add(Me.StoreTab)
        Me.TabControl.Controls.Add(Me.LogTab)
        Me.TabControl.Controls.Add(Me.TabPage1)
        Me.TabControl.Controls.Add(Me.TabPage2)
        Me.TabControl.Location = New System.Drawing.Point(12, 12)
        Me.TabControl.Name = "TabControl"
        Me.TabControl.SelectedIndex = 0
        Me.TabControl.Size = New System.Drawing.Size(891, 777)
        Me.TabControl.TabIndex = 0
        '
        'GameTab
        '
        Me.GameTab.Controls.Add(Me.GameAlterButton)
        Me.GameTab.Controls.Add(Me.gameAddSaveMachine)
        Me.GameTab.Controls.Add(Me.selectMachineForGame)
        Me.GameTab.Controls.Add(Me.removeGamefromMachine)
        Me.GameTab.Controls.Add(Me.addGameToMAchineButton)
        Me.GameTab.Controls.Add(Me.GameMachineLabel)
        Me.GameTab.Controls.Add(Me.GameMachinesListBox)
        Me.GameTab.Controls.Add(Me.GameCancelButton)
        Me.GameTab.Controls.Add(Me.GameEditButton)
        Me.GameTab.Controls.Add(Me.GameDeleteButton)
        Me.GameTab.Controls.Add(Me.GameAddButton)
        Me.GameTab.Controls.Add(Me.GameSaveButton)
        Me.GameTab.Controls.Add(Me.GroupBox1)
        Me.GameTab.Controls.Add(Me.GameListBox)
        Me.GameTab.Location = New System.Drawing.Point(4, 22)
        Me.GameTab.Name = "GameTab"
        Me.GameTab.Padding = New System.Windows.Forms.Padding(3)
        Me.GameTab.Size = New System.Drawing.Size(883, 751)
        Me.GameTab.TabIndex = 0
        Me.GameTab.Text = "Game"
        Me.GameTab.UseVisualStyleBackColor = True
        '
        'GameAlterButton
        '
        Me.GameAlterButton.Location = New System.Drawing.Point(739, 272)
        Me.GameAlterButton.Name = "GameAlterButton"
        Me.GameAlterButton.Size = New System.Drawing.Size(75, 23)
        Me.GameAlterButton.TabIndex = 24
        Me.GameAlterButton.Text = "Update"
        Me.GameAlterButton.UseVisualStyleBackColor = True
        Me.GameAlterButton.Visible = False
        '
        'gameAddSaveMachine
        '
        Me.gameAddSaveMachine.Location = New System.Drawing.Point(412, 530)
        Me.gameAddSaveMachine.Name = "gameAddSaveMachine"
        Me.gameAddSaveMachine.Size = New System.Drawing.Size(75, 23)
        Me.gameAddSaveMachine.TabIndex = 23
        Me.gameAddSaveMachine.Text = "Add"
        Me.gameAddSaveMachine.UseVisualStyleBackColor = True
        Me.gameAddSaveMachine.Visible = False
        '
        'selectMachineForGame
        '
        Me.selectMachineForGame.FormattingEnabled = True
        Me.selectMachineForGame.Location = New System.Drawing.Point(281, 530)
        Me.selectMachineForGame.Name = "selectMachineForGame"
        Me.selectMachineForGame.Size = New System.Drawing.Size(121, 21)
        Me.selectMachineForGame.TabIndex = 22
        Me.selectMachineForGame.Visible = False
        '
        'removeGamefromMachine
        '
        Me.removeGamefromMachine.Location = New System.Drawing.Point(372, 501)
        Me.removeGamefromMachine.Name = "removeGamefromMachine"
        Me.removeGamefromMachine.Size = New System.Drawing.Size(75, 23)
        Me.removeGamefromMachine.TabIndex = 21
        Me.removeGamefromMachine.Text = "Remove"
        Me.removeGamefromMachine.UseVisualStyleBackColor = True
        '
        'addGameToMAchineButton
        '
        Me.addGameToMAchineButton.Location = New System.Drawing.Point(281, 501)
        Me.addGameToMAchineButton.Name = "addGameToMAchineButton"
        Me.addGameToMAchineButton.Size = New System.Drawing.Size(75, 23)
        Me.addGameToMAchineButton.TabIndex = 20
        Me.addGameToMAchineButton.Text = "Add"
        Me.addGameToMAchineButton.UseVisualStyleBackColor = True
        '
        'GameMachineLabel
        '
        Me.GameMachineLabel.AutoSize = True
        Me.GameMachineLabel.Location = New System.Drawing.Point(281, 313)
        Me.GameMachineLabel.Name = "GameMachineLabel"
        Me.GameMachineLabel.Size = New System.Drawing.Size(90, 13)
        Me.GameMachineLabel.TabIndex = 16
        Me.GameMachineLabel.Text = "Arcade Machines"
        '
        'GameMachinesListBox
        '
        Me.GameMachinesListBox.FormattingEnabled = True
        Me.GameMachinesListBox.Location = New System.Drawing.Point(281, 332)
        Me.GameMachinesListBox.Name = "GameMachinesListBox"
        Me.GameMachinesListBox.Size = New System.Drawing.Size(280, 160)
        Me.GameMachinesListBox.TabIndex = 15
        '
        'GameCancelButton
        '
        Me.GameCancelButton.Location = New System.Drawing.Point(641, 272)
        Me.GameCancelButton.Name = "GameCancelButton"
        Me.GameCancelButton.Size = New System.Drawing.Size(75, 23)
        Me.GameCancelButton.TabIndex = 14
        Me.GameCancelButton.Text = "Cancel"
        Me.GameCancelButton.UseVisualStyleBackColor = True
        '
        'GameEditButton
        '
        Me.GameEditButton.Location = New System.Drawing.Point(285, 272)
        Me.GameEditButton.Name = "GameEditButton"
        Me.GameEditButton.Size = New System.Drawing.Size(75, 23)
        Me.GameEditButton.TabIndex = 13
        Me.GameEditButton.Text = "Edit"
        Me.GameEditButton.UseVisualStyleBackColor = True
        '
        'GameDeleteButton
        '
        Me.GameDeleteButton.Location = New System.Drawing.Point(126, 604)
        Me.GameDeleteButton.Name = "GameDeleteButton"
        Me.GameDeleteButton.Size = New System.Drawing.Size(75, 23)
        Me.GameDeleteButton.TabIndex = 12
        Me.GameDeleteButton.Text = "Delete"
        Me.GameDeleteButton.UseVisualStyleBackColor = True
        '
        'GameAddButton
        '
        Me.GameAddButton.Location = New System.Drawing.Point(27, 604)
        Me.GameAddButton.Name = "GameAddButton"
        Me.GameAddButton.Size = New System.Drawing.Size(75, 23)
        Me.GameAddButton.TabIndex = 11
        Me.GameAddButton.Text = "Add"
        Me.GameAddButton.UseVisualStyleBackColor = True
        '
        'GameSaveButton
        '
        Me.GameSaveButton.Location = New System.Drawing.Point(739, 272)
        Me.GameSaveButton.Name = "GameSaveButton"
        Me.GameSaveButton.Size = New System.Drawing.Size(75, 23)
        Me.GameSaveButton.TabIndex = 10
        Me.GameSaveButton.Text = "Save"
        Me.GameSaveButton.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Panel12)
        Me.GroupBox1.Controls.Add(Me.Panel3)
        Me.GroupBox1.Controls.Add(Me.Panel8)
        Me.GroupBox1.Controls.Add(Me.Panel9)
        Me.GroupBox1.Controls.Add(Me.Panel10)
        Me.GroupBox1.Controls.Add(Me.Panel11)
        Me.GroupBox1.Location = New System.Drawing.Point(285, 39)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(529, 227)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Game Info"
        '
        'Panel12
        '
        Me.Panel12.Controls.Add(Me.GameCostInput)
        Me.Panel12.Controls.Add(Me.GameCostLabel)
        Me.Panel12.Location = New System.Drawing.Point(112, 155)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(96, 62)
        Me.Panel12.TabIndex = 5
        '
        'GameCostInput
        '
        Me.GameCostInput.Location = New System.Drawing.Point(15, 30)
        Me.GameCostInput.Name = "GameCostInput"
        Me.GameCostInput.Size = New System.Drawing.Size(44, 20)
        Me.GameCostInput.TabIndex = 0
        '
        'GameCostLabel
        '
        Me.GameCostLabel.AutoSize = True
        Me.GameCostLabel.Location = New System.Drawing.Point(12, 14)
        Me.GameCostLabel.Name = "GameCostLabel"
        Me.GameCostLabel.Size = New System.Drawing.Size(58, 13)
        Me.GameCostLabel.TabIndex = 1
        Me.GameCostLabel.Text = "Credit Cost"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.GamePlayersInput)
        Me.Panel3.Controls.Add(Me.GamePlayersLabel)
        Me.Panel3.Location = New System.Drawing.Point(214, 155)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(121, 62)
        Me.Panel3.TabIndex = 4
        '
        'GamePlayersInput
        '
        Me.GamePlayersInput.Location = New System.Drawing.Point(15, 30)
        Me.GamePlayersInput.Name = "GamePlayersInput"
        Me.GamePlayersInput.Size = New System.Drawing.Size(47, 20)
        Me.GamePlayersInput.TabIndex = 0
        '
        'GamePlayersLabel
        '
        Me.GamePlayersLabel.AutoSize = True
        Me.GamePlayersLabel.Location = New System.Drawing.Point(12, 14)
        Me.GamePlayersLabel.Name = "GamePlayersLabel"
        Me.GamePlayersLabel.Size = New System.Drawing.Size(99, 13)
        Me.GamePlayersLabel.TabIndex = 1
        Me.GamePlayersLabel.Text = "How many players?"
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.GamePointsInput)
        Me.Panel8.Controls.Add(Me.GamePointsLabel)
        Me.Panel8.Location = New System.Drawing.Point(6, 155)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(100, 62)
        Me.Panel8.TabIndex = 4
        '
        'GamePointsInput
        '
        Me.GamePointsInput.Location = New System.Drawing.Point(15, 30)
        Me.GamePointsInput.Name = "GamePointsInput"
        Me.GamePointsInput.Size = New System.Drawing.Size(47, 20)
        Me.GamePointsInput.TabIndex = 0
        '
        'GamePointsLabel
        '
        Me.GamePointsLabel.AutoSize = True
        Me.GamePointsLabel.Location = New System.Drawing.Point(12, 14)
        Me.GamePointsLabel.Name = "GamePointsLabel"
        Me.GamePointsLabel.Size = New System.Drawing.Size(61, 13)
        Me.GamePointsLabel.TabIndex = 1
        Me.GamePointsLabel.Text = "Point Value"
        '
        'Panel9
        '
        Me.Panel9.Controls.Add(Me.GameIDInput)
        Me.Panel9.Controls.Add(Me.GameIDLabel)
        Me.Panel9.Location = New System.Drawing.Point(341, 155)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(123, 62)
        Me.Panel9.TabIndex = 5
        '
        'GameIDInput
        '
        Me.GameIDInput.Location = New System.Drawing.Point(15, 30)
        Me.GameIDInput.Name = "GameIDInput"
        Me.GameIDInput.Size = New System.Drawing.Size(94, 20)
        Me.GameIDInput.TabIndex = 3
        '
        'GameIDLabel
        '
        Me.GameIDLabel.AutoSize = True
        Me.GameIDLabel.Location = New System.Drawing.Point(12, 14)
        Me.GameIDLabel.Name = "GameIDLabel"
        Me.GameIDLabel.Size = New System.Drawing.Size(18, 13)
        Me.GameIDLabel.TabIndex = 1
        Me.GameIDLabel.Text = "ID"
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.GamePublisherInput)
        Me.Panel10.Controls.Add(Me.GamePublisherLabel)
        Me.Panel10.Location = New System.Drawing.Point(6, 87)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(458, 62)
        Me.Panel10.TabIndex = 4
        '
        'GamePublisherInput
        '
        Me.GamePublisherInput.FormattingEnabled = True
        Me.GamePublisherInput.Location = New System.Drawing.Point(15, 30)
        Me.GamePublisherInput.Name = "GamePublisherInput"
        Me.GamePublisherInput.Size = New System.Drawing.Size(410, 21)
        Me.GamePublisherInput.TabIndex = 3
        '
        'GamePublisherLabel
        '
        Me.GamePublisherLabel.AutoSize = True
        Me.GamePublisherLabel.Location = New System.Drawing.Point(12, 14)
        Me.GamePublisherLabel.Name = "GamePublisherLabel"
        Me.GamePublisherLabel.Size = New System.Drawing.Size(50, 13)
        Me.GamePublisherLabel.TabIndex = 1
        Me.GamePublisherLabel.Text = "Publisher"
        '
        'Panel11
        '
        Me.Panel11.Controls.Add(Me.GameNameInput)
        Me.Panel11.Controls.Add(Me.Label5)
        Me.Panel11.Location = New System.Drawing.Point(6, 19)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(458, 62)
        Me.Panel11.TabIndex = 3
        '
        'GameNameInput
        '
        Me.GameNameInput.Enabled = False
        Me.GameNameInput.Location = New System.Drawing.Point(15, 30)
        Me.GameNameInput.Name = "GameNameInput"
        Me.GameNameInput.Size = New System.Drawing.Size(410, 20)
        Me.GameNameInput.TabIndex = 0
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 14)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Name"
        '
        'GameListBox
        '
        Me.GameListBox.FormattingEnabled = True
        Me.GameListBox.Location = New System.Drawing.Point(27, 39)
        Me.GameListBox.Name = "GameListBox"
        Me.GameListBox.Size = New System.Drawing.Size(221, 550)
        Me.GameListBox.TabIndex = 8
        '
        'Publisher
        '
        Me.Publisher.Controls.Add(Me.PublisherCancelButton)
        Me.Publisher.Controls.Add(Me.PublisherEditButton)
        Me.Publisher.Controls.Add(Me.PublisherAddButton)
        Me.Publisher.Controls.Add(Me.PublisherSaveButton)
        Me.Publisher.Controls.Add(Me.PublisherInfo)
        Me.Publisher.Controls.Add(Me.PublisherListBox)
        Me.Publisher.Location = New System.Drawing.Point(4, 22)
        Me.Publisher.Name = "Publisher"
        Me.Publisher.Padding = New System.Windows.Forms.Padding(3)
        Me.Publisher.Size = New System.Drawing.Size(883, 751)
        Me.Publisher.TabIndex = 1
        Me.Publisher.Text = "Publishers"
        Me.Publisher.UseVisualStyleBackColor = True
        '
        'PublisherCancelButton
        '
        Me.PublisherCancelButton.Location = New System.Drawing.Point(683, 307)
        Me.PublisherCancelButton.Name = "PublisherCancelButton"
        Me.PublisherCancelButton.Size = New System.Drawing.Size(75, 23)
        Me.PublisherCancelButton.TabIndex = 14
        Me.PublisherCancelButton.Text = "Cancel"
        Me.PublisherCancelButton.UseVisualStyleBackColor = True
        '
        'PublisherEditButton
        '
        Me.PublisherEditButton.Location = New System.Drawing.Point(327, 307)
        Me.PublisherEditButton.Name = "PublisherEditButton"
        Me.PublisherEditButton.Size = New System.Drawing.Size(75, 23)
        Me.PublisherEditButton.TabIndex = 13
        Me.PublisherEditButton.Text = "Edit"
        Me.PublisherEditButton.UseVisualStyleBackColor = True
        '
        'PublisherAddButton
        '
        Me.PublisherAddButton.Location = New System.Drawing.Point(27, 604)
        Me.PublisherAddButton.Name = "PublisherAddButton"
        Me.PublisherAddButton.Size = New System.Drawing.Size(75, 23)
        Me.PublisherAddButton.TabIndex = 11
        Me.PublisherAddButton.Text = "Add"
        Me.PublisherAddButton.UseVisualStyleBackColor = True
        '
        'PublisherSaveButton
        '
        Me.PublisherSaveButton.Location = New System.Drawing.Point(781, 307)
        Me.PublisherSaveButton.Name = "PublisherSaveButton"
        Me.PublisherSaveButton.Size = New System.Drawing.Size(75, 23)
        Me.PublisherSaveButton.TabIndex = 10
        Me.PublisherSaveButton.Text = "Save"
        Me.PublisherSaveButton.UseVisualStyleBackColor = True
        '
        'PublisherInfo
        '
        Me.PublisherInfo.Controls.Add(Me.Panel4)
        Me.PublisherInfo.Controls.Add(Me.Panel5)
        Me.PublisherInfo.Controls.Add(Me.Panel6)
        Me.PublisherInfo.Controls.Add(Me.Panel7)
        Me.PublisherInfo.Location = New System.Drawing.Point(327, 54)
        Me.PublisherInfo.Name = "PublisherInfo"
        Me.PublisherInfo.Size = New System.Drawing.Size(529, 236)
        Me.PublisherInfo.TabIndex = 9
        Me.PublisherInfo.TabStop = False
        Me.PublisherInfo.Text = "Publisher Info"
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.PublisherLocationInput)
        Me.Panel4.Controls.Add(Me.PublisherLocationLabel)
        Me.Panel4.Location = New System.Drawing.Point(6, 155)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(458, 62)
        Me.Panel4.TabIndex = 4
        '
        'PublisherLocationInput
        '
        Me.PublisherLocationInput.Location = New System.Drawing.Point(15, 30)
        Me.PublisherLocationInput.Name = "PublisherLocationInput"
        Me.PublisherLocationInput.Size = New System.Drawing.Size(410, 20)
        Me.PublisherLocationInput.TabIndex = 0
        '
        'PublisherLocationLabel
        '
        Me.PublisherLocationLabel.AutoSize = True
        Me.PublisherLocationLabel.Location = New System.Drawing.Point(12, 14)
        Me.PublisherLocationLabel.Name = "PublisherLocationLabel"
        Me.PublisherLocationLabel.Size = New System.Drawing.Size(48, 13)
        Me.PublisherLocationLabel.TabIndex = 1
        Me.PublisherLocationLabel.Text = "Location"
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.PublisherIsIndependent)
        Me.Panel5.Location = New System.Drawing.Point(230, 87)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(234, 62)
        Me.Panel5.TabIndex = 5
        '
        'PublisherIsIndependent
        '
        Me.PublisherIsIndependent.AutoSize = True
        Me.PublisherIsIndependent.Location = New System.Drawing.Point(18, 33)
        Me.PublisherIsIndependent.Name = "PublisherIsIndependent"
        Me.PublisherIsIndependent.Size = New System.Drawing.Size(92, 17)
        Me.PublisherIsIndependent.TabIndex = 2
        Me.PublisherIsIndependent.Text = "Independent?"
        Me.PublisherIsIndependent.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.PublisherIDInput)
        Me.Panel6.Controls.Add(Me.PublisherIDLabel)
        Me.Panel6.Location = New System.Drawing.Point(6, 87)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(218, 62)
        Me.Panel6.TabIndex = 4
        '
        'PublisherIDInput
        '
        Me.PublisherIDInput.Location = New System.Drawing.Point(15, 30)
        Me.PublisherIDInput.Name = "PublisherIDInput"
        Me.PublisherIDInput.Size = New System.Drawing.Size(176, 20)
        Me.PublisherIDInput.TabIndex = 2
        '
        'PublisherIDLabel
        '
        Me.PublisherIDLabel.AutoSize = True
        Me.PublisherIDLabel.Location = New System.Drawing.Point(12, 14)
        Me.PublisherIDLabel.Name = "PublisherIDLabel"
        Me.PublisherIDLabel.Size = New System.Drawing.Size(18, 13)
        Me.PublisherIDLabel.TabIndex = 1
        Me.PublisherIDLabel.Text = "ID"
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.PublisherNameInput)
        Me.Panel7.Controls.Add(Me.PublisherNameLabel)
        Me.Panel7.Location = New System.Drawing.Point(6, 19)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(458, 62)
        Me.Panel7.TabIndex = 3
        '
        'PublisherNameInput
        '
        Me.PublisherNameInput.Enabled = False
        Me.PublisherNameInput.Location = New System.Drawing.Point(15, 30)
        Me.PublisherNameInput.Name = "PublisherNameInput"
        Me.PublisherNameInput.Size = New System.Drawing.Size(410, 20)
        Me.PublisherNameInput.TabIndex = 0
        '
        'PublisherNameLabel
        '
        Me.PublisherNameLabel.AutoSize = True
        Me.PublisherNameLabel.Location = New System.Drawing.Point(12, 14)
        Me.PublisherNameLabel.Name = "PublisherNameLabel"
        Me.PublisherNameLabel.Size = New System.Drawing.Size(35, 13)
        Me.PublisherNameLabel.TabIndex = 1
        Me.PublisherNameLabel.Text = "Name"
        '
        'PublisherListBox
        '
        Me.PublisherListBox.FormattingEnabled = True
        Me.PublisherListBox.Location = New System.Drawing.Point(27, 39)
        Me.PublisherListBox.Name = "PublisherListBox"
        Me.PublisherListBox.Size = New System.Drawing.Size(221, 550)
        Me.PublisherListBox.TabIndex = 8
        '
        'SupplierTab
        '
        Me.SupplierTab.Controls.Add(Me.SupplierCancelEditButton)
        Me.SupplierTab.Controls.Add(Me.SupplierEditButton)
        Me.SupplierTab.Controls.Add(Me.SupplierDeleteButton)
        Me.SupplierTab.Controls.Add(Me.SupplierAddButton)
        Me.SupplierTab.Controls.Add(Me.SupplierSaveButton)
        Me.SupplierTab.Controls.Add(Me.SupplierInfo)
        Me.SupplierTab.Controls.Add(Me.Supplier_ListBox)
        Me.SupplierTab.Location = New System.Drawing.Point(4, 22)
        Me.SupplierTab.Name = "SupplierTab"
        Me.SupplierTab.Size = New System.Drawing.Size(883, 751)
        Me.SupplierTab.TabIndex = 2
        Me.SupplierTab.Text = "Suppliers"
        Me.SupplierTab.UseVisualStyleBackColor = True
        '
        'SupplierCancelEditButton
        '
        Me.SupplierCancelEditButton.Location = New System.Drawing.Point(673, 358)
        Me.SupplierCancelEditButton.Name = "SupplierCancelEditButton"
        Me.SupplierCancelEditButton.Size = New System.Drawing.Size(75, 23)
        Me.SupplierCancelEditButton.TabIndex = 7
        Me.SupplierCancelEditButton.Text = "Cancel"
        Me.SupplierCancelEditButton.UseVisualStyleBackColor = True
        '
        'SupplierEditButton
        '
        Me.SupplierEditButton.Location = New System.Drawing.Point(317, 358)
        Me.SupplierEditButton.Name = "SupplierEditButton"
        Me.SupplierEditButton.Size = New System.Drawing.Size(75, 23)
        Me.SupplierEditButton.TabIndex = 6
        Me.SupplierEditButton.Text = "Edit"
        Me.SupplierEditButton.UseVisualStyleBackColor = True
        '
        'SupplierDeleteButton
        '
        Me.SupplierDeleteButton.Location = New System.Drawing.Point(116, 589)
        Me.SupplierDeleteButton.Name = "SupplierDeleteButton"
        Me.SupplierDeleteButton.Size = New System.Drawing.Size(75, 23)
        Me.SupplierDeleteButton.TabIndex = 5
        Me.SupplierDeleteButton.Text = "Delete"
        Me.SupplierDeleteButton.UseVisualStyleBackColor = True
        '
        'SupplierAddButton
        '
        Me.SupplierAddButton.Location = New System.Drawing.Point(17, 589)
        Me.SupplierAddButton.Name = "SupplierAddButton"
        Me.SupplierAddButton.Size = New System.Drawing.Size(75, 23)
        Me.SupplierAddButton.TabIndex = 4
        Me.SupplierAddButton.Text = "Add"
        Me.SupplierAddButton.UseVisualStyleBackColor = True
        '
        'SupplierSaveButton
        '
        Me.SupplierSaveButton.Location = New System.Drawing.Point(771, 358)
        Me.SupplierSaveButton.Name = "SupplierSaveButton"
        Me.SupplierSaveButton.Size = New System.Drawing.Size(75, 23)
        Me.SupplierSaveButton.TabIndex = 3
        Me.SupplierSaveButton.Text = "Save"
        Me.SupplierSaveButton.UseVisualStyleBackColor = True
        '
        'SupplierInfo
        '
        Me.SupplierInfo.Controls.Add(Me.Panel2)
        Me.SupplierInfo.Controls.Add(Me.Panel1)
        Me.SupplierInfo.Controls.Add(Me.SupplierPhoneDetails)
        Me.SupplierInfo.Controls.Add(Me.SupplierNIFDetails)
        Me.SupplierInfo.Controls.Add(Me.SupplierNameDetails)
        Me.SupplierInfo.Location = New System.Drawing.Point(317, 39)
        Me.SupplierInfo.Name = "SupplierInfo"
        Me.SupplierInfo.Size = New System.Drawing.Size(529, 301)
        Me.SupplierInfo.TabIndex = 2
        Me.SupplierInfo.TabStop = False
        Me.SupplierInfo.Text = "Supplier Info"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.SupplierAddressInput)
        Me.Panel2.Controls.Add(Me.SupplierAddressLabel)
        Me.Panel2.Location = New System.Drawing.Point(6, 223)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(458, 62)
        Me.Panel2.TabIndex = 4
        '
        'SupplierAddressInput
        '
        Me.SupplierAddressInput.Location = New System.Drawing.Point(15, 30)
        Me.SupplierAddressInput.Name = "SupplierAddressInput"
        Me.SupplierAddressInput.Size = New System.Drawing.Size(410, 20)
        Me.SupplierAddressInput.TabIndex = 0
        '
        'SupplierAddressLabel
        '
        Me.SupplierAddressLabel.AutoSize = True
        Me.SupplierAddressLabel.Location = New System.Drawing.Point(12, 14)
        Me.SupplierAddressLabel.Name = "SupplierAddressLabel"
        Me.SupplierAddressLabel.Size = New System.Drawing.Size(45, 13)
        Me.SupplierAddressLabel.TabIndex = 1
        Me.SupplierAddressLabel.Text = "Address"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.SupplierEmailInput)
        Me.Panel1.Controls.Add(Me.SupplierEmailLabel)
        Me.Panel1.Location = New System.Drawing.Point(6, 155)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(458, 62)
        Me.Panel1.TabIndex = 4
        '
        'SupplierEmailInput
        '
        Me.SupplierEmailInput.Location = New System.Drawing.Point(15, 30)
        Me.SupplierEmailInput.Name = "SupplierEmailInput"
        Me.SupplierEmailInput.Size = New System.Drawing.Size(410, 20)
        Me.SupplierEmailInput.TabIndex = 0
        '
        'SupplierEmailLabel
        '
        Me.SupplierEmailLabel.AutoSize = True
        Me.SupplierEmailLabel.Location = New System.Drawing.Point(12, 14)
        Me.SupplierEmailLabel.Name = "SupplierEmailLabel"
        Me.SupplierEmailLabel.Size = New System.Drawing.Size(32, 13)
        Me.SupplierEmailLabel.TabIndex = 1
        Me.SupplierEmailLabel.Text = "Email"
        '
        'SupplierPhoneDetails
        '
        Me.SupplierPhoneDetails.Controls.Add(Me.SupplierPhoneInput)
        Me.SupplierPhoneDetails.Controls.Add(Me.SupplierPhoneLabel)
        Me.SupplierPhoneDetails.Location = New System.Drawing.Point(230, 87)
        Me.SupplierPhoneDetails.Name = "SupplierPhoneDetails"
        Me.SupplierPhoneDetails.Size = New System.Drawing.Size(234, 62)
        Me.SupplierPhoneDetails.TabIndex = 5
        '
        'SupplierPhoneInput
        '
        Me.SupplierPhoneInput.Location = New System.Drawing.Point(15, 30)
        Me.SupplierPhoneInput.Name = "SupplierPhoneInput"
        Me.SupplierPhoneInput.Size = New System.Drawing.Size(176, 20)
        Me.SupplierPhoneInput.TabIndex = 3
        '
        'SupplierPhoneLabel
        '
        Me.SupplierPhoneLabel.AutoSize = True
        Me.SupplierPhoneLabel.Location = New System.Drawing.Point(12, 14)
        Me.SupplierPhoneLabel.Name = "SupplierPhoneLabel"
        Me.SupplierPhoneLabel.Size = New System.Drawing.Size(38, 13)
        Me.SupplierPhoneLabel.TabIndex = 1
        Me.SupplierPhoneLabel.Text = "Phone"
        '
        'SupplierNIFDetails
        '
        Me.SupplierNIFDetails.Controls.Add(Me.SupplierNIFInput)
        Me.SupplierNIFDetails.Controls.Add(Me.SupplierNIFLabel)
        Me.SupplierNIFDetails.Location = New System.Drawing.Point(6, 87)
        Me.SupplierNIFDetails.Name = "SupplierNIFDetails"
        Me.SupplierNIFDetails.Size = New System.Drawing.Size(218, 62)
        Me.SupplierNIFDetails.TabIndex = 4
        '
        'SupplierNIFInput
        '
        Me.SupplierNIFInput.Location = New System.Drawing.Point(15, 30)
        Me.SupplierNIFInput.Name = "SupplierNIFInput"
        Me.SupplierNIFInput.Size = New System.Drawing.Size(176, 20)
        Me.SupplierNIFInput.TabIndex = 2
        '
        'SupplierNIFLabel
        '
        Me.SupplierNIFLabel.AutoSize = True
        Me.SupplierNIFLabel.Location = New System.Drawing.Point(12, 14)
        Me.SupplierNIFLabel.Name = "SupplierNIFLabel"
        Me.SupplierNIFLabel.Size = New System.Drawing.Size(24, 13)
        Me.SupplierNIFLabel.TabIndex = 1
        Me.SupplierNIFLabel.Text = "NIF"
        '
        'SupplierNameDetails
        '
        Me.SupplierNameDetails.Controls.Add(Me.SupplierNameInput)
        Me.SupplierNameDetails.Controls.Add(Me.SupplierNameLabel)
        Me.SupplierNameDetails.Location = New System.Drawing.Point(6, 19)
        Me.SupplierNameDetails.Name = "SupplierNameDetails"
        Me.SupplierNameDetails.Size = New System.Drawing.Size(458, 62)
        Me.SupplierNameDetails.TabIndex = 3
        '
        'SupplierNameInput
        '
        Me.SupplierNameInput.Enabled = False
        Me.SupplierNameInput.Location = New System.Drawing.Point(15, 30)
        Me.SupplierNameInput.Name = "SupplierNameInput"
        Me.SupplierNameInput.Size = New System.Drawing.Size(410, 20)
        Me.SupplierNameInput.TabIndex = 0
        '
        'SupplierNameLabel
        '
        Me.SupplierNameLabel.AutoSize = True
        Me.SupplierNameLabel.Location = New System.Drawing.Point(12, 14)
        Me.SupplierNameLabel.Name = "SupplierNameLabel"
        Me.SupplierNameLabel.Size = New System.Drawing.Size(35, 13)
        Me.SupplierNameLabel.TabIndex = 1
        Me.SupplierNameLabel.Text = "Name"
        '
        'Supplier_ListBox
        '
        Me.Supplier_ListBox.FormattingEnabled = True
        Me.Supplier_ListBox.Location = New System.Drawing.Point(17, 24)
        Me.Supplier_ListBox.Name = "Supplier_ListBox"
        Me.Supplier_ListBox.Size = New System.Drawing.Size(221, 550)
        Me.Supplier_ListBox.TabIndex = 0
        '
        'StoreTab
        '
        Me.StoreTab.Controls.Add(Me.GroupBox4)
        Me.StoreTab.Controls.Add(Me.StoreCancelButton)
        Me.StoreTab.Controls.Add(Me.StoreEditButton)
        Me.StoreTab.Controls.Add(Me.StoreDeleteButton)
        Me.StoreTab.Controls.Add(Me.StoreAddButton)
        Me.StoreTab.Controls.Add(Me.StoreSaveButton)
        Me.StoreTab.Controls.Add(Me.GroupBox2)
        Me.StoreTab.Controls.Add(Me.StoreListBox)
        Me.StoreTab.Location = New System.Drawing.Point(4, 22)
        Me.StoreTab.Name = "StoreTab"
        Me.StoreTab.Size = New System.Drawing.Size(883, 751)
        Me.StoreTab.TabIndex = 3
        Me.StoreTab.Text = "Stores"
        Me.StoreTab.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.EmployeeDeleteButton)
        Me.GroupBox4.Controls.Add(Me.EmployeeAddButton)
        Me.GroupBox4.Controls.Add(Me.EmployeeSaveButton)
        Me.GroupBox4.Controls.Add(Me.EmployeeCancelButton)
        Me.GroupBox4.Controls.Add(Me.EmployeeEditButton)
        Me.GroupBox4.Controls.Add(Me.Panel25)
        Me.GroupBox4.Controls.Add(Me.Panel24)
        Me.GroupBox4.Controls.Add(Me.Panel22)
        Me.GroupBox4.Controls.Add(Me.Panel23)
        Me.GroupBox4.Controls.Add(Me.Panel21)
        Me.GroupBox4.Controls.Add(Me.Panel14)
        Me.GroupBox4.Controls.Add(Me.EmployeeListBox)
        Me.GroupBox4.Location = New System.Drawing.Point(264, 192)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(603, 524)
        Me.GroupBox4.TabIndex = 10
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Employees"
        '
        'EmployeeDeleteButton
        '
        Me.EmployeeDeleteButton.Location = New System.Drawing.Point(87, 289)
        Me.EmployeeDeleteButton.Name = "EmployeeDeleteButton"
        Me.EmployeeDeleteButton.Size = New System.Drawing.Size(75, 23)
        Me.EmployeeDeleteButton.TabIndex = 15
        Me.EmployeeDeleteButton.Text = "Delete"
        Me.EmployeeDeleteButton.UseVisualStyleBackColor = True
        '
        'EmployeeAddButton
        '
        Me.EmployeeAddButton.Location = New System.Drawing.Point(6, 289)
        Me.EmployeeAddButton.Name = "EmployeeAddButton"
        Me.EmployeeAddButton.Size = New System.Drawing.Size(75, 23)
        Me.EmployeeAddButton.TabIndex = 15
        Me.EmployeeAddButton.Text = "Add"
        Me.EmployeeAddButton.UseVisualStyleBackColor = True
        '
        'EmployeeSaveButton
        '
        Me.EmployeeSaveButton.Location = New System.Drawing.Point(484, 261)
        Me.EmployeeSaveButton.Name = "EmployeeSaveButton"
        Me.EmployeeSaveButton.Size = New System.Drawing.Size(75, 23)
        Me.EmployeeSaveButton.TabIndex = 15
        Me.EmployeeSaveButton.Text = "Save"
        Me.EmployeeSaveButton.UseVisualStyleBackColor = True
        '
        'EmployeeCancelButton
        '
        Me.EmployeeCancelButton.Location = New System.Drawing.Point(484, 232)
        Me.EmployeeCancelButton.Name = "EmployeeCancelButton"
        Me.EmployeeCancelButton.Size = New System.Drawing.Size(75, 23)
        Me.EmployeeCancelButton.TabIndex = 15
        Me.EmployeeCancelButton.Text = "Cancel"
        Me.EmployeeCancelButton.UseVisualStyleBackColor = True
        '
        'EmployeeEditButton
        '
        Me.EmployeeEditButton.Location = New System.Drawing.Point(484, 232)
        Me.EmployeeEditButton.Name = "EmployeeEditButton"
        Me.EmployeeEditButton.Size = New System.Drawing.Size(75, 23)
        Me.EmployeeEditButton.TabIndex = 15
        Me.EmployeeEditButton.Text = "Edit"
        Me.EmployeeEditButton.UseVisualStyleBackColor = True
        '
        'Panel25
        '
        Me.Panel25.Controls.Add(Me.EmpTaskList)
        Me.Panel25.Controls.Add(Me.employeeFuncLabel)
        Me.Panel25.Controls.Add(Me.Label15)
        Me.Panel25.Controls.Add(Me.EmployeeEndVal)
        Me.Panel25.Controls.Add(Me.Label12)
        Me.Panel25.Controls.Add(Me.EmployeeStartVal)
        Me.Panel25.Controls.Add(Me.Label10)
        Me.Panel25.Location = New System.Drawing.Point(233, 289)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(364, 189)
        Me.Panel25.TabIndex = 9
        '
        'EmpTaskList
        '
        Me.EmpTaskList.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.EmpTaskList.Alignment = System.Windows.Forms.ListViewAlignment.Left
        Me.EmpTaskList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.EmpTaskList.HideSelection = False
        Me.EmpTaskList.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem1})
        Me.EmpTaskList.Location = New System.Drawing.Point(104, 89)
        Me.EmpTaskList.Name = "EmpTaskList"
        Me.EmpTaskList.Size = New System.Drawing.Size(245, 83)
        Me.EmpTaskList.TabIndex = 9
        Me.EmpTaskList.UseCompatibleStateImageBehavior = False
        Me.EmpTaskList.View = System.Windows.Forms.View.List
        '
        'employeeFuncLabel
        '
        Me.employeeFuncLabel.AutoSize = True
        Me.employeeFuncLabel.Location = New System.Drawing.Point(45, 89)
        Me.employeeFuncLabel.Name = "employeeFuncLabel"
        Me.employeeFuncLabel.Size = New System.Drawing.Size(51, 13)
        Me.employeeFuncLabel.TabIndex = 8
        Me.employeeFuncLabel.Text = "Function:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(12, 14)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(83, 13)
        Me.Label15.TabIndex = 7
        Me.Label15.Text = "Schedule Code:"
        '
        'EmployeeEndVal
        '
        Me.EmployeeEndVal.AutoSize = True
        Me.EmployeeEndVal.Location = New System.Drawing.Point(101, 38)
        Me.EmployeeEndVal.Name = "EmployeeEndVal"
        Me.EmployeeEndVal.Size = New System.Drawing.Size(86, 13)
        Me.EmployeeEndVal.TabIndex = 5
        Me.EmployeeEndVal.Text = "PLACEHOLDER"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(48, 38)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(47, 13)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = "Ends At:"
        '
        'EmployeeStartVal
        '
        Me.EmployeeStartVal.AutoSize = True
        Me.EmployeeStartVal.Location = New System.Drawing.Point(101, 62)
        Me.EmployeeStartVal.Name = "EmployeeStartVal"
        Me.EmployeeStartVal.Size = New System.Drawing.Size(86, 13)
        Me.EmployeeStartVal.TabIndex = 3
        Me.EmployeeStartVal.Text = "PLACEHOLDER"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(45, 62)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(50, 13)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Starts At:"
        '
        'Panel24
        '
        Me.Panel24.Controls.Add(Me.EmployeeNIFInput)
        Me.Panel24.Controls.Add(Me.Label9)
        Me.Panel24.Location = New System.Drawing.Point(233, 223)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(218, 60)
        Me.Panel24.TabIndex = 8
        '
        'EmployeeNIFInput
        '
        Me.EmployeeNIFInput.Location = New System.Drawing.Point(15, 30)
        Me.EmployeeNIFInput.Name = "EmployeeNIFInput"
        Me.EmployeeNIFInput.Size = New System.Drawing.Size(189, 20)
        Me.EmployeeNIFInput.TabIndex = 2
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(12, 14)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(24, 13)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "NIF"
        '
        'Panel22
        '
        Me.Panel22.Controls.Add(Me.EmployeeSalaryInput)
        Me.Panel22.Controls.Add(Me.Label3)
        Me.Panel22.Location = New System.Drawing.Point(457, 155)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(140, 62)
        Me.Panel22.TabIndex = 7
        '
        'EmployeeSalaryInput
        '
        Me.EmployeeSalaryInput.Location = New System.Drawing.Point(15, 30)
        Me.EmployeeSalaryInput.Name = "EmployeeSalaryInput"
        Me.EmployeeSalaryInput.Size = New System.Drawing.Size(110, 20)
        Me.EmployeeSalaryInput.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(36, 13)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Salary"
        '
        'Panel23
        '
        Me.Panel23.Controls.Add(Me.EmployeePhoneInput)
        Me.Panel23.Controls.Add(Me.Label8)
        Me.Panel23.Location = New System.Drawing.Point(233, 155)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(218, 62)
        Me.Panel23.TabIndex = 7
        '
        'EmployeePhoneInput
        '
        Me.EmployeePhoneInput.Location = New System.Drawing.Point(15, 30)
        Me.EmployeePhoneInput.Name = "EmployeePhoneInput"
        Me.EmployeePhoneInput.Size = New System.Drawing.Size(189, 20)
        Me.EmployeePhoneInput.TabIndex = 2
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 14)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Phone Nº"
        '
        'Panel21
        '
        Me.Panel21.Controls.Add(Me.EmployeeEmailInput)
        Me.Panel21.Controls.Add(Me.Label2)
        Me.Panel21.Location = New System.Drawing.Point(233, 87)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(364, 62)
        Me.Panel21.TabIndex = 6
        '
        'EmployeeEmailInput
        '
        Me.EmployeeEmailInput.Location = New System.Drawing.Point(15, 30)
        Me.EmployeeEmailInput.Name = "EmployeeEmailInput"
        Me.EmployeeEmailInput.Size = New System.Drawing.Size(334, 20)
        Me.EmployeeEmailInput.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Email"
        '
        'Panel14
        '
        Me.Panel14.Controls.Add(Me.EmployeeNameInput)
        Me.Panel14.Controls.Add(Me.Label1)
        Me.Panel14.Location = New System.Drawing.Point(233, 19)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(364, 62)
        Me.Panel14.TabIndex = 5
        '
        'EmployeeNameInput
        '
        Me.EmployeeNameInput.Location = New System.Drawing.Point(15, 30)
        Me.EmployeeNameInput.Name = "EmployeeNameInput"
        Me.EmployeeNameInput.Size = New System.Drawing.Size(334, 20)
        Me.EmployeeNameInput.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Name"
        '
        'EmployeeListBox
        '
        Me.EmployeeListBox.FormattingEnabled = True
        Me.EmployeeListBox.Location = New System.Drawing.Point(6, 19)
        Me.EmployeeListBox.Name = "EmployeeListBox"
        Me.EmployeeListBox.Size = New System.Drawing.Size(221, 264)
        Me.EmployeeListBox.TabIndex = 15
        '
        'StoreCancelButton
        '
        Me.StoreCancelButton.Location = New System.Drawing.Point(698, 145)
        Me.StoreCancelButton.Name = "StoreCancelButton"
        Me.StoreCancelButton.Size = New System.Drawing.Size(75, 23)
        Me.StoreCancelButton.TabIndex = 14
        Me.StoreCancelButton.Text = "Cancel"
        Me.StoreCancelButton.UseVisualStyleBackColor = True
        '
        'StoreEditButton
        '
        Me.StoreEditButton.Location = New System.Drawing.Point(264, 145)
        Me.StoreEditButton.Name = "StoreEditButton"
        Me.StoreEditButton.Size = New System.Drawing.Size(75, 23)
        Me.StoreEditButton.TabIndex = 13
        Me.StoreEditButton.Text = "Edit"
        Me.StoreEditButton.UseVisualStyleBackColor = True
        '
        'StoreDeleteButton
        '
        Me.StoreDeleteButton.Location = New System.Drawing.Point(108, 192)
        Me.StoreDeleteButton.Name = "StoreDeleteButton"
        Me.StoreDeleteButton.Size = New System.Drawing.Size(75, 23)
        Me.StoreDeleteButton.TabIndex = 12
        Me.StoreDeleteButton.Text = "Delete"
        Me.StoreDeleteButton.UseVisualStyleBackColor = True
        '
        'StoreAddButton
        '
        Me.StoreAddButton.Location = New System.Drawing.Point(27, 192)
        Me.StoreAddButton.Name = "StoreAddButton"
        Me.StoreAddButton.Size = New System.Drawing.Size(75, 23)
        Me.StoreAddButton.TabIndex = 11
        Me.StoreAddButton.Text = "Add"
        Me.StoreAddButton.UseVisualStyleBackColor = True
        '
        'StoreSaveButton
        '
        Me.StoreSaveButton.Location = New System.Drawing.Point(786, 145)
        Me.StoreSaveButton.Name = "StoreSaveButton"
        Me.StoreSaveButton.Size = New System.Drawing.Size(75, 23)
        Me.StoreSaveButton.TabIndex = 10
        Me.StoreSaveButton.Text = "Save"
        Me.StoreSaveButton.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Panel17)
        Me.GroupBox2.Controls.Add(Me.Panel16)
        Me.GroupBox2.Location = New System.Drawing.Point(264, 39)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(603, 100)
        Me.GroupBox2.TabIndex = 9
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Store Info"
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.StoreIDInput)
        Me.Panel17.Controls.Add(Me.Label6)
        Me.Panel17.Location = New System.Drawing.Point(490, 19)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(107, 62)
        Me.Panel17.TabIndex = 3
        '
        'StoreIDInput
        '
        Me.StoreIDInput.Enabled = False
        Me.StoreIDInput.Location = New System.Drawing.Point(15, 30)
        Me.StoreIDInput.Name = "StoreIDInput"
        Me.StoreIDInput.Size = New System.Drawing.Size(54, 20)
        Me.StoreIDInput.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 14)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Store ID"
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.StoreLocationInput)
        Me.Panel16.Controls.Add(Me.Label4)
        Me.Panel16.Location = New System.Drawing.Point(6, 19)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(467, 62)
        Me.Panel16.TabIndex = 4
        '
        'StoreLocationInput
        '
        Me.StoreLocationInput.Location = New System.Drawing.Point(15, 30)
        Me.StoreLocationInput.Name = "StoreLocationInput"
        Me.StoreLocationInput.Size = New System.Drawing.Size(430, 20)
        Me.StoreLocationInput.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 14)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Location"
        '
        'StoreListBox
        '
        Me.StoreListBox.FormattingEnabled = True
        Me.StoreListBox.Location = New System.Drawing.Point(27, 39)
        Me.StoreListBox.Name = "StoreListBox"
        Me.StoreListBox.Size = New System.Drawing.Size(221, 147)
        Me.StoreListBox.TabIndex = 8
        '
        'LogTab
        '
        Me.LogTab.Controls.Add(Me.GroupBox3)
        Me.LogTab.Controls.Add(Me.Label7)
        Me.LogTab.Controls.Add(Me.EmployeeLogs)
        Me.LogTab.Controls.Add(Me.RedeemShowLogs)
        Me.LogTab.Controls.Add(Me.topupShowLogs)
        Me.LogTab.Controls.Add(Me.ShowMaintenanceLog)
        Me.LogTab.Controls.Add(Me.ShowPlayLog)
        Me.LogTab.Controls.Add(Me.LogGrid)
        Me.LogTab.Location = New System.Drawing.Point(4, 22)
        Me.LogTab.Name = "LogTab"
        Me.LogTab.Size = New System.Drawing.Size(883, 751)
        Me.LogTab.TabIndex = 4
        Me.LogTab.Text = "Logs"
        Me.LogTab.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.StatsuseEnd)
        Me.GroupBox3.Controls.Add(Me.statsUseStart)
        Me.GroupBox3.Controls.Add(Me.Label25)
        Me.GroupBox3.Controls.Add(Me.gameStat)
        Me.GroupBox3.Controls.Add(Me.Label24)
        Me.GroupBox3.Controls.Add(Me.userStat)
        Me.GroupBox3.Controls.Add(Me.EndTimeStats)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.statisticsButtonGo)
        Me.GroupBox3.Controls.Add(Me.totalTime)
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.Controls.Add(Me.avgTime)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.StartTimeStats)
        Me.GroupBox3.Location = New System.Drawing.Point(15, 531)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(343, 203)
        Me.GroupBox3.TabIndex = 8
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Statistics:"
        '
        'totalTime
        '
        Me.totalTime.AutoSize = True
        Me.totalTime.Location = New System.Drawing.Point(85, 172)
        Me.totalTime.Name = "totalTime"
        Me.totalTime.Size = New System.Drawing.Size(92, 13)
        Me.totalTime.TabIndex = 12
        Me.totalTime.Text = "[PLACEHOLDER]"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(19, 172)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(60, 13)
        Me.Label23.TabIndex = 11
        Me.Label23.Text = "Total Time:"
        '
        'avgTime
        '
        Me.avgTime.AutoSize = True
        Me.avgTime.Location = New System.Drawing.Point(85, 150)
        Me.avgTime.Name = "avgTime"
        Me.avgTime.Size = New System.Drawing.Size(92, 13)
        Me.avgTime.TabIndex = 10
        Me.avgTime.Text = "[PLACEHOLDER]"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(6, 150)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(76, 13)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "Average Time:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(42, 95)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(37, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "Since:"
        '
        'StartTimeStats
        '
        Me.StartTimeStats.Location = New System.Drawing.Point(85, 89)
        Me.StartTimeStats.Name = "StartTimeStats"
        Me.StartTimeStats.Size = New System.Drawing.Size(200, 20)
        Me.StartTimeStats.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(364, 19)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(96, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Filter By Employee:"
        '
        'EmployeeLogs
        '
        Me.EmployeeLogs.FormattingEnabled = True
        Me.EmployeeLogs.Location = New System.Drawing.Point(466, 16)
        Me.EmployeeLogs.Name = "EmployeeLogs"
        Me.EmployeeLogs.Size = New System.Drawing.Size(165, 21)
        Me.EmployeeLogs.TabIndex = 5
        '
        'RedeemShowLogs
        '
        Me.RedeemShowLogs.Location = New System.Drawing.Point(271, 14)
        Me.RedeemShowLogs.Name = "RedeemShowLogs"
        Me.RedeemShowLogs.Size = New System.Drawing.Size(87, 23)
        Me.RedeemShowLogs.TabIndex = 4
        Me.RedeemShowLogs.Text = "Redeem Logs"
        Me.RedeemShowLogs.UseVisualStyleBackColor = True
        '
        'topupShowLogs
        '
        Me.topupShowLogs.Location = New System.Drawing.Point(190, 14)
        Me.topupShowLogs.Name = "topupShowLogs"
        Me.topupShowLogs.Size = New System.Drawing.Size(75, 23)
        Me.topupShowLogs.TabIndex = 3
        Me.topupShowLogs.Text = "Top Up Log"
        Me.topupShowLogs.UseVisualStyleBackColor = True
        '
        'ShowMaintenanceLog
        '
        Me.ShowMaintenanceLog.Location = New System.Drawing.Point(96, 14)
        Me.ShowMaintenanceLog.Name = "ShowMaintenanceLog"
        Me.ShowMaintenanceLog.Size = New System.Drawing.Size(88, 23)
        Me.ShowMaintenanceLog.TabIndex = 2
        Me.ShowMaintenanceLog.Text = "Maintenance"
        Me.ShowMaintenanceLog.UseVisualStyleBackColor = True
        '
        'ShowPlayLog
        '
        Me.ShowPlayLog.Location = New System.Drawing.Point(15, 14)
        Me.ShowPlayLog.Name = "ShowPlayLog"
        Me.ShowPlayLog.Size = New System.Drawing.Size(75, 23)
        Me.ShowPlayLog.TabIndex = 1
        Me.ShowPlayLog.Text = "Playing Logs"
        Me.ShowPlayLog.UseVisualStyleBackColor = True
        '
        'LogGrid
        '
        Me.LogGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.LogGrid.Location = New System.Drawing.Point(15, 43)
        Me.LogGrid.Name = "LogGrid"
        Me.LogGrid.Size = New System.Drawing.Size(852, 482)
        Me.LogGrid.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GameMachineAddButton)
        Me.TabPage1.Controls.Add(Me.GameMachineSaveButton)
        Me.TabPage1.Controls.Add(Me.GameMachineCancelButton)
        Me.TabPage1.Controls.Add(Me.GameMachineEditButton)
        Me.TabPage1.Controls.Add(Me.GroupBox5)
        Me.TabPage1.Controls.Add(Me.Label21)
        Me.TabPage1.Controls.Add(Me.MachinaListBox)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(883, 751)
        Me.TabPage1.TabIndex = 5
        Me.TabPage1.Text = "Machines"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GameMachineAddButton
        '
        Me.GameMachineAddButton.Location = New System.Drawing.Point(153, 359)
        Me.GameMachineAddButton.Name = "GameMachineAddButton"
        Me.GameMachineAddButton.Size = New System.Drawing.Size(75, 23)
        Me.GameMachineAddButton.TabIndex = 29
        Me.GameMachineAddButton.Text = "Add"
        Me.GameMachineAddButton.UseVisualStyleBackColor = True
        '
        'GameMachineSaveButton
        '
        Me.GameMachineSaveButton.Location = New System.Drawing.Point(646, 556)
        Me.GameMachineSaveButton.Name = "GameMachineSaveButton"
        Me.GameMachineSaveButton.Size = New System.Drawing.Size(75, 23)
        Me.GameMachineSaveButton.TabIndex = 28
        Me.GameMachineSaveButton.Text = "Save"
        Me.GameMachineSaveButton.UseVisualStyleBackColor = True
        '
        'GameMachineCancelButton
        '
        Me.GameMachineCancelButton.Location = New System.Drawing.Point(565, 556)
        Me.GameMachineCancelButton.Name = "GameMachineCancelButton"
        Me.GameMachineCancelButton.Size = New System.Drawing.Size(75, 23)
        Me.GameMachineCancelButton.TabIndex = 27
        Me.GameMachineCancelButton.Text = "Cancel"
        Me.GameMachineCancelButton.UseVisualStyleBackColor = True
        '
        'GameMachineEditButton
        '
        Me.GameMachineEditButton.Location = New System.Drawing.Point(454, 556)
        Me.GameMachineEditButton.Name = "GameMachineEditButton"
        Me.GameMachineEditButton.Size = New System.Drawing.Size(75, 23)
        Me.GameMachineEditButton.TabIndex = 26
        Me.GameMachineEditButton.Text = "Edit"
        Me.GameMachineEditButton.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Panel27)
        Me.GroupBox5.Controls.Add(Me.Panel28)
        Me.GroupBox5.Controls.Add(Me.Panel29)
        Me.GroupBox5.Controls.Add(Me.Panel30)
        Me.GroupBox5.Controls.Add(Me.Panel31)
        Me.GroupBox5.Controls.Add(Me.Panel32)
        Me.GroupBox5.Location = New System.Drawing.Point(454, 190)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(275, 360)
        Me.GroupBox5.TabIndex = 23
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Machine Info"
        '
        'Panel27
        '
        Me.Panel27.Controls.Add(Me.GameMachineRentDurInput)
        Me.Panel27.Controls.Add(Me.Label13)
        Me.Panel27.Controls.Add(Me.GameMachineRentInput)
        Me.Panel27.Controls.Add(Me.GameMachineRentCost)
        Me.Panel27.Location = New System.Drawing.Point(6, 291)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(263, 62)
        Me.Panel27.TabIndex = 6
        '
        'GameMachineRentDurInput
        '
        Me.GameMachineRentDurInput.Location = New System.Drawing.Point(164, 30)
        Me.GameMachineRentDurInput.Name = "GameMachineRentDurInput"
        Me.GameMachineRentDurInput.Size = New System.Drawing.Size(83, 20)
        Me.GameMachineRentDurInput.TabIndex = 3
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(161, 14)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(73, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Rent Duration"
        '
        'GameMachineRentInput
        '
        Me.GameMachineRentInput.Location = New System.Drawing.Point(15, 30)
        Me.GameMachineRentInput.Name = "GameMachineRentInput"
        Me.GameMachineRentInput.Size = New System.Drawing.Size(83, 20)
        Me.GameMachineRentInput.TabIndex = 0
        '
        'GameMachineRentCost
        '
        Me.GameMachineRentCost.AutoSize = True
        Me.GameMachineRentCost.Location = New System.Drawing.Point(12, 14)
        Me.GameMachineRentCost.Name = "GameMachineRentCost"
        Me.GameMachineRentCost.Size = New System.Drawing.Size(45, 13)
        Me.GameMachineRentCost.TabIndex = 1
        Me.GameMachineRentCost.Text = "Label14"
        '
        'Panel28
        '
        Me.Panel28.Controls.Add(Me.GameMachineSupplierInput)
        Me.Panel28.Controls.Add(Me.Label16)
        Me.Panel28.Location = New System.Drawing.Point(6, 223)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(263, 62)
        Me.Panel28.TabIndex = 5
        '
        'GameMachineSupplierInput
        '
        Me.GameMachineSupplierInput.FormattingEnabled = True
        Me.GameMachineSupplierInput.Location = New System.Drawing.Point(15, 30)
        Me.GameMachineSupplierInput.Name = "GameMachineSupplierInput"
        Me.GameMachineSupplierInput.Size = New System.Drawing.Size(232, 21)
        Me.GameMachineSupplierInput.TabIndex = 2
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(12, 14)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(45, 13)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "Supplier"
        '
        'Panel29
        '
        Me.Panel29.Controls.Add(Me.GameMachineLocationInput)
        Me.Panel29.Controls.Add(Me.Label17)
        Me.Panel29.Location = New System.Drawing.Point(6, 155)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(263, 62)
        Me.Panel29.TabIndex = 4
        '
        'GameMachineLocationInput
        '
        Me.GameMachineLocationInput.Location = New System.Drawing.Point(15, 30)
        Me.GameMachineLocationInput.Name = "GameMachineLocationInput"
        Me.GameMachineLocationInput.Size = New System.Drawing.Size(232, 20)
        Me.GameMachineLocationInput.TabIndex = 0
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(12, 14)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(48, 13)
        Me.Label17.TabIndex = 1
        Me.Label17.Text = "Location"
        '
        'Panel30
        '
        Me.Panel30.Controls.Add(Me.TextBox5)
        Me.Panel30.Controls.Add(Me.Label18)
        Me.Panel30.Location = New System.Drawing.Point(341, 155)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(123, 62)
        Me.Panel30.TabIndex = 5
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(15, 30)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(94, 20)
        Me.TextBox5.TabIndex = 3
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(12, 14)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(18, 13)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "ID"
        '
        'Panel31
        '
        Me.Panel31.Controls.Add(Me.GameMachineManuInput)
        Me.Panel31.Controls.Add(Me.Label19)
        Me.Panel31.Location = New System.Drawing.Point(6, 87)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(263, 62)
        Me.Panel31.TabIndex = 4
        '
        'GameMachineManuInput
        '
        Me.GameMachineManuInput.Location = New System.Drawing.Point(15, 30)
        Me.GameMachineManuInput.Name = "GameMachineManuInput"
        Me.GameMachineManuInput.Size = New System.Drawing.Size(232, 20)
        Me.GameMachineManuInput.TabIndex = 2
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(12, 14)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(70, 13)
        Me.Label19.TabIndex = 1
        Me.Label19.Text = "Manufacturer"
        '
        'Panel32
        '
        Me.Panel32.Controls.Add(Me.GameMachineSerialInput)
        Me.Panel32.Controls.Add(Me.Label20)
        Me.Panel32.Location = New System.Drawing.Point(6, 19)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(263, 62)
        Me.Panel32.TabIndex = 3
        '
        'GameMachineSerialInput
        '
        Me.GameMachineSerialInput.Enabled = False
        Me.GameMachineSerialInput.Location = New System.Drawing.Point(15, 30)
        Me.GameMachineSerialInput.Name = "GameMachineSerialInput"
        Me.GameMachineSerialInput.Size = New System.Drawing.Size(232, 20)
        Me.GameMachineSerialInput.TabIndex = 0
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(12, 14)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(73, 13)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "Serial Number"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(153, 171)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(90, 13)
        Me.Label21.TabIndex = 25
        Me.Label21.Text = "Arcade Machines"
        '
        'MachinaListBox
        '
        Me.MachinaListBox.FormattingEnabled = True
        Me.MachinaListBox.Location = New System.Drawing.Point(153, 190)
        Me.MachinaListBox.Name = "MachinaListBox"
        Me.MachinaListBox.Size = New System.Drawing.Size(280, 160)
        Me.MachinaListBox.TabIndex = 24
        '
        'TabPage2
        '
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(883, 751)
        Me.TabPage2.TabIndex = 6
        Me.TabPage2.Text = "TabPage2"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'RedeemedBindingSource1
        '
        Me.RedeemedBindingSource1.DataMember = "Redeemed"
        Me.RedeemedBindingSource1.DataSource = Me.ArcadeData
        '
        'ArcadeData
        '
        Me.ArcadeData.DataSetName = "ArcadeData"
        Me.ArcadeData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ToppedUpBindingSource
        '
        Me.ToppedUpBindingSource.DataMember = "ToppedUp"
        Me.ToppedUpBindingSource.DataSource = Me.ArcadeData
        '
        'MaintainedBindingSource
        '
        Me.MaintainedBindingSource.DataMember = "Maintained"
        Me.MaintainedBindingSource.DataSource = Me.ArcadeData
        '
        'PlayedBindingSource
        '
        Me.PlayedBindingSource.DataMember = "Played"
        Me.PlayedBindingSource.DataSource = Me.ArcadeData
        '
        'RedeemedBindingSource
        '
        Me.RedeemedBindingSource.DataMember = "Redeemed"
        Me.RedeemedBindingSource.DataSource = Me.ArcadeData
        '
        'RedeemedTableAdapter
        '
        Me.RedeemedTableAdapter.ClearBeforeFill = True
        '
        'ToppedUpTableAdapter
        '
        Me.ToppedUpTableAdapter.ClearBeforeFill = True
        '
        'MaintainedTableAdapter
        '
        Me.MaintainedTableAdapter.ClearBeforeFill = True
        '
        'PlayedTableAdapter
        '
        Me.PlayedTableAdapter.ClearBeforeFill = True
        '
        'statisticsButtonGo
        '
        Me.statisticsButtonGo.Location = New System.Drawing.Point(210, 10)
        Me.statisticsButtonGo.Name = "statisticsButtonGo"
        Me.statisticsButtonGo.Size = New System.Drawing.Size(75, 23)
        Me.statisticsButtonGo.TabIndex = 13
        Me.statisticsButtonGo.Text = "Calculate!"
        Me.statisticsButtonGo.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(48, 115)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(31, 13)
        Me.Label22.TabIndex = 14
        Me.Label22.Text = "Until:"
        '
        'EndTimeStats
        '
        Me.EndTimeStats.Location = New System.Drawing.Point(85, 115)
        Me.EndTimeStats.Name = "EndTimeStats"
        Me.EndTimeStats.Size = New System.Drawing.Size(200, 20)
        Me.EndTimeStats.TabIndex = 15
        '
        'userStat
        '
        Me.userStat.FormattingEnabled = True
        Me.userStat.Location = New System.Drawing.Point(164, 39)
        Me.userStat.Name = "userStat"
        Me.userStat.Size = New System.Drawing.Size(121, 21)
        Me.userStat.TabIndex = 16
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(11, 42)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(134, 13)
        Me.Label24.TabIndex = 17
        Me.Label24.Text = "User? (For All, leave blank)"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(11, 65)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(140, 13)
        Me.Label25.TabIndex = 19
        Me.Label25.Text = "Game? (For All, leave blank)"
        '
        'gameStat
        '
        Me.gameStat.FormattingEnabled = True
        Me.gameStat.Location = New System.Drawing.Point(164, 62)
        Me.gameStat.Name = "gameStat"
        Me.gameStat.Size = New System.Drawing.Size(121, 21)
        Me.gameStat.TabIndex = 18
        '
        'statsUseStart
        '
        Me.statsUseStart.AutoSize = True
        Me.statsUseStart.Location = New System.Drawing.Point(288, 91)
        Me.statsUseStart.Name = "statsUseStart"
        Me.statsUseStart.Size = New System.Drawing.Size(49, 17)
        Me.statsUseStart.TabIndex = 20
        Me.statsUseStart.Text = "use?"
        Me.statsUseStart.UseVisualStyleBackColor = True
        '
        'StatsuseEnd
        '
        Me.StatsuseEnd.AutoSize = True
        Me.StatsuseEnd.Location = New System.Drawing.Point(288, 114)
        Me.StatsuseEnd.Name = "StatsuseEnd"
        Me.StatsuseEnd.Size = New System.Drawing.Size(49, 17)
        Me.StatsuseEnd.TabIndex = 21
        Me.StatsuseEnd.Text = "use?"
        Me.StatsuseEnd.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(915, 823)
        Me.Controls.Add(Me.TabControl)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabControl.ResumeLayout(False)
        Me.GameTab.ResumeLayout(False)
        Me.GameTab.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Publisher.ResumeLayout(False)
        Me.PublisherInfo.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.SupplierTab.ResumeLayout(False)
        Me.SupplierInfo.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.SupplierPhoneDetails.ResumeLayout(False)
        Me.SupplierPhoneDetails.PerformLayout()
        Me.SupplierNIFDetails.ResumeLayout(False)
        Me.SupplierNIFDetails.PerformLayout()
        Me.SupplierNameDetails.ResumeLayout(False)
        Me.SupplierNameDetails.PerformLayout()
        Me.StoreTab.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout()
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        Me.Panel23.ResumeLayout(False)
        Me.Panel23.PerformLayout()
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.LogTab.ResumeLayout(False)
        Me.LogTab.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.LogGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout()
        Me.Panel30.ResumeLayout(False)
        Me.Panel30.PerformLayout()
        Me.Panel31.ResumeLayout(False)
        Me.Panel31.PerformLayout()
        Me.Panel32.ResumeLayout(False)
        Me.Panel32.PerformLayout()
        CType(Me.RedeemedBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ArcadeData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ToppedUpBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaintainedBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PlayedBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RedeemedBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl As TabControl
    Friend WithEvents GameTab As TabPage
    Friend WithEvents Publisher As TabPage
    Friend WithEvents SupplierTab As TabPage
    Friend WithEvents SupplierInfo As GroupBox
    Friend WithEvents SupplierNIFDetails As Panel
    Friend WithEvents SupplierNIFLabel As Label
    Friend WithEvents SupplierNameDetails As Panel
    Friend WithEvents SupplierNameInput As TextBox
    Friend WithEvents SupplierNameLabel As Label
    Friend WithEvents Supplier_ListBox As ListBox
    Friend WithEvents SupplierPhoneDetails As Panel
    Friend WithEvents SupplierPhoneLabel As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents SupplierEmailInput As TextBox
    Friend WithEvents SupplierEmailLabel As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents SupplierAddressInput As TextBox
    Friend WithEvents SupplierAddressLabel As Label
    Friend WithEvents SupplierCancelEditButton As Button
    Friend WithEvents SupplierEditButton As Button
    Friend WithEvents SupplierDeleteButton As Button
    Friend WithEvents SupplierAddButton As Button
    Friend WithEvents SupplierSaveButton As Button
    Friend WithEvents SupplierPhoneInput As TextBox
    Friend WithEvents SupplierNIFInput As TextBox
    Friend WithEvents PublisherCancelButton As Button
    Friend WithEvents PublisherEditButton As Button
    Friend WithEvents PublisherAddButton As Button
    Friend WithEvents PublisherSaveButton As Button
    Friend WithEvents PublisherInfo As GroupBox
    Friend WithEvents Panel4 As Panel
    Friend WithEvents PublisherLocationInput As TextBox
    Friend WithEvents PublisherLocationLabel As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents PublisherIDInput As TextBox
    Friend WithEvents PublisherIDLabel As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents PublisherNameInput As TextBox
    Friend WithEvents PublisherNameLabel As Label
    Friend WithEvents PublisherListBox As ListBox
    Friend WithEvents PublisherIsIndependent As CheckBox
    Friend WithEvents GameMachinesListBox As ListBox
    Friend WithEvents GameCancelButton As Button
    Friend WithEvents GameEditButton As Button
    Friend WithEvents GameDeleteButton As Button
    Friend WithEvents GameSaveButton As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Panel12 As Panel
    Friend WithEvents GameCostInput As TextBox
    Friend WithEvents GameCostLabel As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents GamePlayersInput As TextBox
    Friend WithEvents GamePlayersLabel As Label
    Friend WithEvents Panel8 As Panel
    Friend WithEvents GamePointsInput As TextBox
    Friend WithEvents GamePointsLabel As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents GameIDInput As TextBox
    Friend WithEvents GameIDLabel As Label
    Friend WithEvents Panel10 As Panel
    Friend WithEvents GamePublisherLabel As Label
    Friend WithEvents Panel11 As Panel
    Friend WithEvents GameNameInput As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents GameListBox As ListBox
    Friend WithEvents GameAddButton As Button
    Friend WithEvents GameMachineLabel As Label
    Friend WithEvents StoreTab As TabPage
    Friend WithEvents StoreCancelButton As Button
    Friend WithEvents StoreEditButton As Button
    Friend WithEvents StoreDeleteButton As Button
    Friend WithEvents StoreAddButton As Button
    Friend WithEvents StoreSaveButton As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Panel17 As Panel
    Friend WithEvents StoreIDInput As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel16 As Panel
    Friend WithEvents StoreLocationInput As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents StoreListBox As ListBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents EmployeeSaveButton As Button
    Friend WithEvents EmployeeCancelButton As Button
    Friend WithEvents EmployeeEditButton As Button
    Friend WithEvents Panel25 As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents EmployeeEndVal As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents EmployeeStartVal As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Panel24 As Panel
    Friend WithEvents EmployeeNIFInput As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Panel22 As Panel
    Friend WithEvents EmployeeSalaryInput As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel23 As Panel
    Friend WithEvents EmployeePhoneInput As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Panel21 As Panel
    Friend WithEvents EmployeeEmailInput As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel14 As Panel
    Friend WithEvents EmployeeNameInput As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents EmployeeListBox As ListBox
    Friend WithEvents EmployeeDeleteButton As Button
    Friend WithEvents EmployeeAddButton As Button
    Friend WithEvents employeeFuncLabel As Label
    Friend WithEvents EmpTaskList As ListView
    Friend WithEvents GamePublisherInput As ComboBox
    Friend WithEvents addGameToMAchineButton As Button
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents GameMachineAddButton As Button
    Friend WithEvents GameMachineSaveButton As Button
    Friend WithEvents GameMachineCancelButton As Button
    Friend WithEvents GameMachineEditButton As Button
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Panel27 As Panel
    Friend WithEvents GameMachineRentDurInput As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents GameMachineRentCost As Label
    Friend WithEvents Panel28 As Panel
    Friend WithEvents GameMachineSupplierInput As ComboBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Panel29 As Panel
    Friend WithEvents GameMachineLocationInput As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Panel30 As Panel
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Panel31 As Panel
    Friend WithEvents GameMachineManuInput As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Panel32 As Panel
    Friend WithEvents GameMachineSerialInput As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents MachinaListBox As ListBox
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents removeGamefromMachine As Button
    Friend WithEvents selectMachineForGame As ComboBox
    Friend WithEvents GameMachineRentInput As TextBox
    Friend WithEvents gameAddSaveMachine As Button
    Friend WithEvents GameAlterButton As Button
    Friend WithEvents ArcadeData As ArcadeData
    Friend WithEvents RedeemedBindingSource As BindingSource
    Friend WithEvents RedeemedTableAdapter As ArcadeDataTableAdapters.RedeemedTableAdapter
    Friend WithEvents RedeemedBindingSource1 As BindingSource
    Friend WithEvents ToppedUpBindingSource As BindingSource
    Friend WithEvents ToppedUpTableAdapter As ArcadeDataTableAdapters.ToppedUpTableAdapter
    Friend WithEvents MaintainedBindingSource As BindingSource
    Friend WithEvents MaintainedTableAdapter As ArcadeDataTableAdapters.MaintainedTableAdapter
    Friend WithEvents PlayedBindingSource As BindingSource
    Friend WithEvents PlayedTableAdapter As ArcadeDataTableAdapters.PlayedTableAdapter
    Friend WithEvents LogTab As TabPage
    Friend WithEvents RedeemShowLogs As Button
    Friend WithEvents topupShowLogs As Button
    Friend WithEvents ShowMaintenanceLog As Button
    Friend WithEvents ShowPlayLog As Button
    Friend WithEvents LogGrid As DataGridView
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents totalTime As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents StartTimeStats As DateTimePicker
    Friend WithEvents Label7 As Label
    Friend WithEvents EmployeeLogs As ComboBox
    Friend WithEvents avgTime As Label
    Friend WithEvents statisticsButtonGo As Button
    Friend WithEvents EndTimeStats As DateTimePicker
    Friend WithEvents Label22 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents userStat As ComboBox
    Friend WithEvents Label25 As Label
    Friend WithEvents gameStat As ComboBox
    Friend WithEvents StatsuseEnd As CheckBox
    Friend WithEvents statsUseStart As CheckBox
End Class
